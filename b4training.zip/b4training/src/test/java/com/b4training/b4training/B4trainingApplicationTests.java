package com.b4training.b4training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B4trainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
