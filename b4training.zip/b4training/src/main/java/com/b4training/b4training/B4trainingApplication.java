package com.b4training.b4training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B4trainingApplication {

	public static void main(String[] args) {
		SpringApplication.run(B4trainingApplication.class, args);
	}

}
